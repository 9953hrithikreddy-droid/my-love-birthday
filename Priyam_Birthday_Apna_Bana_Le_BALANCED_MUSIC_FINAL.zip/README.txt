Priyam Birthday Website — Apna Bana Le

The music is embedded directly inside index.html. No separate music file is required.
Open index.html in Chrome. If audible autoplay is blocked by Chrome, the first tap anywhere on the page starts the song automatically; no music button/icon is shown.
